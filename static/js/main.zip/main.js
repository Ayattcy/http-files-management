const sfx = {
    open: new Audio('/sounds/open_files.mp3'),
    back: new Audio('/sounds/back.mp3')
};

// 自定义对话框系统
const Dialog = {
    overlay: null,
    dialog: null,
    title: null,
    message: null,
    inputWrapper: null,
    input: null,
    cancelBtn: null,
    okBtn: null,
    resolve: null,
    reject: null,

    init() {
        this.overlay = document.getElementById('custom_dialog_overlay');
        this.dialog = document.getElementById('custom_dialog');
        this.title = document.getElementById('custom_dialog_title');
        this.message = document.getElementById('custom_dialog_message');
        this.inputWrapper = document.getElementById('custom_dialog_input_wrapper');
        this.input = document.getElementById('custom_dialog_input');
        this.cancelBtn = document.getElementById('custom_dialog_cancel');
        this.okBtn = document.getElementById('custom_dialog_ok');

        if (!this.overlay || !this.dialog || !this.title || !this.message || 
            !this.inputWrapper || !this.input || !this.cancelBtn || !this.okBtn) {
            console.error('Dialog.init: 部分元素未找到', {
                overlay: !!this.overlay,
                dialog: !!this.dialog,
                title: !!this.title,
                message: !!this.message,
                inputWrapper: !!this.inputWrapper,
                input: !!this.input,
                cancelBtn: !!this.cancelBtn,
                okBtn: !!this.okBtn
            });
            return;
        }

        this.cancelBtn.addEventListener('click', () => this.onCancel());
        this.okBtn.addEventListener('click', () => this.onOk());
        this.input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') this.onOk();
            if (e.key === 'Escape') this.onCancel();
        });
        this.overlay.addEventListener('click', (e) => {
            if (e.target === this.overlay) this.onCancel();
        });
        
        console.log('Dialog.init: 初始化完成');
    },

    show() {
        this.overlay.classList.add('active');
        if (this.inputWrapper.style.display !== 'none') {
            this.input.focus();
        }
    },

    hide() {
        this.overlay.classList.remove('active');
    },

    onOk() {
        const value = this.input.value;
        this.hide();
        if (this.resolve) this.resolve(value);
    },

    onCancel() {
        this.hide();
        if (this.reject) this.reject(new Error('cancelled'));
    },

    alert(message, title = '提示') {
        return new Promise((resolve) => {
            this.title.textContent = title;
            this.message.textContent = message;
            this.inputWrapper.style.display = 'none';
            this.cancelBtn.style.display = 'none';
            this.okBtn.textContent = '确定';
            this.resolve = () => resolve(true);
            this.reject = null;
            this.show();
        });
    },

    confirm(message, title = '确认') {
        return new Promise((resolve, reject) => {
            this.title.textContent = title;
            this.message.textContent = message;
            this.inputWrapper.style.display = 'none';
            this.cancelBtn.style.display = 'block';
            this.cancelBtn.textContent = '取消';
            this.okBtn.textContent = '确定';
            this.resolve = () => resolve(true);
            this.reject = () => resolve(false);
            this.show();
        });
    },

    prompt(message, defaultValue = '', title = '输入') {
        return new Promise((resolve, reject) => {
            this.title.textContent = title;
            this.message.textContent = message;
            this.inputWrapper.style.display = 'block';
            this.input.value = defaultValue;
            this.cancelBtn.style.display = 'block';
            this.cancelBtn.textContent = '取消';
            this.okBtn.textContent = '确定';
            this.resolve = () => resolve(this.input.value);
            this.reject = () => resolve(null);
            this.show();
            this.input.select();
        });
    }
};

const state = {
    currentPath: '/',
    items: [],
    selected: new Set(),
    clipboard: { action: null, items: [] },
    ws: null,
    sortMode: 'name'
};

// 操作状态管理
const OperationManager = {
    isOperating: false,
    pendingSync: false,
    syncDelay: 1000,
    syncTimer: null,
    autoSyncInterval: null,
    
    start() {
        this.isOperating = true;
        this.clearSyncTimer();
    },
    
    end() {
        this.isOperating = false;
        if (this.pendingSync) {
            this.pendingSync = false;
            this.sync();
        }
    },
    
    requestSync(delay = this.syncDelay) {
        if (this.isOperating) {
            this.pendingSync = true;
            return;
        }
        
        this.clearSyncTimer();
        this.syncTimer = setTimeout(() => {
            this.sync();
        }, delay);
    },
    
    sync() {
        this.pendingSync = false;
        if (state.ws?.readyState === WebSocket.OPEN) {
            send({cmd: 'ls', path: state.currentPath});
        }
    },
    
    clearSyncTimer() {
        if (this.syncTimer) {
            clearTimeout(this.syncTimer);
            this.syncTimer = null;
        }
    },
    
    startAutoSync(interval = 2000) {
        this.stopAutoSync();
        this.autoSyncInterval = setInterval(() => {
            if (!this.isOperating && !this.pendingSync) {
                this.sync();
            }
        }, interval);
    },
    
    stopAutoSync() {
        if (this.autoSyncInterval) {
            clearInterval(this.autoSyncInterval);
            this.autoSyncInterval = null;
        }
    }
};

function getIcon(name, type) {
    if (type === 'dir') return '文件夹';
    const ext = name.split('.').pop().toLowerCase();
    const map = {
        txt: '文本文档', pdf: 'pdf',
        doc: 'word文字', docx: 'word文字',
        xls: '表格', xlsx: '表格',
        ppt: '幻灯片文件', pptx: '幻灯片文件',
        py: 'py文件', js: 'js', css: 'css',
        html: 'html', json: 'json', ini: 'ini',
        c: 'C类语言', cpp: 'C类语言', java: 'java类文件',
        jpg: '图片', jpeg: '图片', png: '图片', gif: '图片',
        mp4: '视频', avi: '视频', mkv: '视频',
        mp3: '音频', wav: '音频',
        exe: '可执行文件', msi: 'msi', dll: 'dll', bat: 'bat',
        apk: 'apk',
        zip: '压缩包', rar: '压缩包', '7z': '压缩包',
        log: '日志类',toml:'toml',
    };
    return map[ext] || '其他文件';
}

function formatSize(bytes) {
    if (bytes === 0) return '-';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (bytes >= 1024 && i < units.length - 1) {
        bytes /= 1024;
        i++;
    }
    return bytes.toFixed(1) + ' ' + units[i];
}

function connect(retryCount = 0) {
    const maxRetries = 10;
    const baseDelay = 3000;
    
    const ws = new WebSocket(`ws://${location.host}/ws`);
    ws.onopen = () => {
        console.log('Connected');
        send({cmd: 'ls', path: '/'});
        OperationManager.startAutoSync(2000);
    };
    ws.onmessage = (e) => {
        const msg = JSON.parse(e.data);
        handleMessage(msg);
    };
    ws.onclose = () => {
        console.log('Disconnected, retrying...');
        if (retryCount < maxRetries) {
            const delay = Math.min(baseDelay * Math.pow(2, retryCount), 60000);
            setTimeout(() => connect(retryCount + 1), delay);
        } else {
            Dialog.alert('连接失败，请刷新页面重试');
        }
    };
    state.ws = ws;
}

function send(data) {
    if (state.ws?.readyState === WebSocket.OPEN) {
        state.ws.send(JSON.stringify(data));
    }
}

function handleMessage(msg) {
    switch(msg.type) {
        case 'ls':
            // 检查文件列表是否真的变化了
            const hasChanged = !state.items || 
                               state.items.length !== msg.items.length ||
                               state.currentPath !== msg.path ||
                               JSON.stringify(state.items.map(i => i.id).sort()) !== 
                               JSON.stringify(msg.items.map(i => i.id).sort());
            
            state.items = msg.items;
            state.currentPath = msg.path;
            applySort();
            
            // 只移除已不存在的文件的选择状态，保留其他选择
            const currentIds = new Set(state.items.map(i => i.id));
            for (const id of state.selected) {
                if (!currentIds.has(id)) {
                    state.selected.delete(id);
                }
            }
            
            // 只有真正变化时才重新渲染
            if (hasChanged) {
                render();
                renderBreadcrumb();
            }
            OperationManager.end();
            break;
        case 'diff':
            msg.changes.forEach(change => {
                if (change.op === 'del') {
                    state.items = state.items.filter(i => i.id !== change.id);
                } else if (change.op === 'mod') {
                    const item = state.items.find(i => i.id === change.id);
                    if (item) item.name = change.name;
                }
            });
            render();
            break;
        case 'error':
            Dialog.alert('Error: ' + msg.msg);
            break;
    }
}

function applySort() {
    switch(state.sortMode) {
        case 'name':
            state.items.sort((a, b) => {
                if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
                return a.name.localeCompare(b.name, 'zh-CN');
            });
            break;
        case 'size':
            state.items.sort((a, b) => {
                if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
                return b.size - a.size;
            });
            break;
        case 'time':
            state.items.sort((a, b) => {
                if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
                return b.mtime - a.mtime;
            });
            break;
    }
}

function render() {
    const body = document.getElementById('body');
    if (state.items.length === 0) {
        body.innerHTML = '<div id="empty">此文件夹为空</div>';
        return;
    }
    body.innerHTML = state.items.map(item => {
        const icon = getIcon(item.name, item.type);
        const sel = state.selected.has(item.id) ? 'selected' : '';
        const sizeText = item.type === 'dir' ? '' : `<span style="color:#666;font-size:12px;">${formatSize(item.size)}</span>`;
        return `
            <div class="files ${sel}"
                 data-id="${item.id}"
                 data-type="${item.type}"
                 data-name="${esc(item.name)}">
                <img src="img/${icon}.png" class="file_icon" draggable="false" onerror="this.src='img/其他文件.png'"/>
                <span class="file_name">${esc(item.name)}<br>${sizeText}</span>
            </div>
        `;
    }).join('');
}

function renderBreadcrumb() {
    const nav = document.getElementById('nav_body');
    const parts = state.currentPath.split('/').filter(Boolean);
    let html = '';
    const rootClass = state.currentPath === '/' ? 'onit' : 'not_onit';
    html += `<div class="${rootClass}" onclick="goHome()">home</div>`;
    let build = '';
    parts.forEach((p, i) => {
        build += '/' + p;
        const last = i === parts.length - 1;
        const cls = last ? 'onit' : 'not_onit';
        html += `<span class="point_icon"><img src="img/右-箭头.png" class="point_icon"/></span>`;
        html += `<div class="${cls}" onclick="goPath('${build}')">${esc(p)}</div>`;
    });
    nav.innerHTML = html;
}

function goHome() {
    sfx.back.play();
    send({cmd: 'ls', path: '/'});
}

function goPath(path) {
    sfx.back.play();
    send({cmd: 'ls', path: path});
}

// 监听窗口大小变化（CSS Grid 自动处理布局，此处保留用于其他用途）
let resizeTimer = null;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
        // CSS Grid 自动处理布局，无需额外操作
    }, 100);
});

// 标记是否正在显示右键菜单，用于区分左键和右键
let isContextMenuOpen = false;

function bindEvents() {
    const body = document.getElementById('body');
    let lastClickTime = 0;
    let lastClickId = null;
    
    body.addEventListener('mousedown', e => {
        // 忽略右键（button === 2），右键由 contextmenu 事件处理
        if (e.button === 2) return;
        
        if (e.target.closest('#file_menu') || e.target.closest('#blank_menu') || 
            e.target.closest('#custom_dialog_overlay')) {
            return;
        }
        
        const f = e.target.closest('.files');
        
        if (!f) {
            if (state.selected.size > 0) {
                state.selected.clear();
                render();
            }
            return;
        }
        
        const id = f.dataset.id;
        const now = Date.now();
        
        // 检测双击
        if (now - lastClickTime < 300 && lastClickId === id) {
            return;
        }
        
        lastClickTime = now;
        lastClickId = id;
        
        // Ctrl/Cmd + 点击 = 切换选择（多选模式）
        if (e.ctrlKey || e.metaKey) {
            if (state.selected.has(id)) {
                state.selected.delete(id);
            } else {
                state.selected.add(id);
            }
            render();
            return;
        }
        
        // 普通点击 = 单选模式
        if (state.selected.has(id) && state.selected.size > 1) {
            return;
        }
        
        state.selected.clear();
        state.selected.add(id);
        render();
    });
    
    body.addEventListener('dblclick', e => {
        const f = e.target.closest('.files');
        if (!f) return;
        const { id, type, name } = f.dataset;
        if (type === 'dir') {
            sfx.open.play();
            const newPath = state.currentPath === '/' ? `/${name}` : `${state.currentPath}/${name}`;
            send({cmd: 'ls', path: newPath});
        } else {
            openFile(id);
        }
    });
    
    document.getElementById('refresh_btn').onclick = () => {
        sfx.back.play();
        send({cmd: 'ls', path: state.currentPath});
    };
    
    document.getElementById('ser_in').addEventListener('input', e => {
        const term = e.target.value.toLowerCase();
        if (!term) {
            render();
            return;
        }
        const filtered = state.items.filter(i => i.name.toLowerCase().includes(term));
        document.getElementById('body').innerHTML = filtered.map(item => {
            const icon = getIcon(item.name, item.type);
            const sel = state.selected.has(item.id) ? 'selected' : ''; // 修复：保留选中状态
            const sizeText = item.type === 'dir' ? '' : `<span style="color:#666;font-size:12px;">${formatSize(item.size)}</span>`;
            return `
                <div class="files ${sel}" data-id="${item.id}" data-type="${item.type}">
                    <img src="img/${icon}.png" class="file_icon" draggable="false" onerror="this.src='img/其他文件.png'"/>
                    <span class="file_name">${esc(item.name)}<br>${sizeText}</span>
                </div>
            `;
        }).join('');
    });
}

// 存储当前右键选中的文件ID，替代 dataset 存储
let currentRightClickIds = [];

function bindMenu() {
    const fileMenu = document.getElementById('file_menu');
    const blankMenu = document.getElementById('blank_menu');
    
    function getRightClickSelectedIds(targetFile) {
        const targetId = targetFile?.dataset?.id;
        if (!targetId) return [];
        
        // 如果右键点击的文件已在当前选中列表中，则对所有选中项进行操作
        if (state.selected.has(targetId)) {
            return Array.from(state.selected);
        }
        
        // 否则：只返回当前右键点击的文件，不改变现有的选择状态
        // 这样用户可以在保持多选的情况下，对另一个文件进行右键操作
        return [targetId];
    }
    
    // 调整菜单位置，防止溢出屏幕
    function adjustMenuPosition(menu, x, y) {
        const menuWidth = menu.offsetWidth || 150; // 默认预估宽度
        const menuHeight = menu.offsetHeight || 200;
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        
        let left = x;
        let top = y;
        
        // 右边界检测
        if (left + menuWidth > windowWidth) {
            left = windowWidth - menuWidth - 10;
        }
        
        // 下边界检测
        if (top + menuHeight > windowHeight) {
            top = windowHeight - menuHeight - 10;
        }
        
        // 确保不超出左上角
        left = Math.max(5, left);
        top = Math.max(5, top);
        
        menu.style.left = left + 'px';
        menu.style.top = top + 'px';
    }
    
    document.addEventListener('contextmenu', e => {
        e.preventDefault();
        
        // 标记右键菜单即将打开
        isContextMenuOpen = true;
        
        fileMenu.style.display = 'none';
        blankMenu.style.display = 'none';
        
        const f = e.target.closest('.files');
        
        if (f) {
            currentRightClickIds = getRightClickSelectedIds(f);
            
            // 根据选中数量更新菜单项状态
            updateMenuItemsForSelection(fileMenu, currentRightClickIds.length);
            
            fileMenu.style.display = 'block';
            adjustMenuPosition(fileMenu, e.pageX, e.pageY);
        } else {
            currentRightClickIds = [];
            
            const pasteItem = blankMenu.querySelector('[data-action="paste"]');
            if (pasteItem) {
                pasteItem.style.color = state.clipboard.action ? '#353a4a' : '#888';
                pasteItem.style.pointerEvents = state.clipboard.action ? 'auto' : 'none';
            }
            
            blankMenu.style.display = 'block';
            adjustMenuPosition(blankMenu, e.pageX, e.pageY);
        }
    });
    
    document.addEventListener('click', e => {
        if (!e.target.closest('#file_menu') && !e.target.closest('#blank_menu')) {
            fileMenu.style.display = 'none';
            blankMenu.style.display = 'none';
            isContextMenuOpen = false;
        }
    });
    
    fileMenu.addEventListener('click', e => {
        const menuItem = e.target.closest('.menu_item');
        if (!menuItem) return;
        const action = menuItem.dataset.action;
        if (!action) return;
        
        handleAction(action, currentRightClickIds);
        fileMenu.style.display = 'none';
        isContextMenuOpen = false;
    });
    
    blankMenu.addEventListener('click', e => {
        const menuItem = e.target.closest('.menu_item');
        if (!menuItem) return;
        const action = menuItem.dataset.action;
        if (!action) return;
        handleAction(action, []);
        blankMenu.style.display = 'none';
        isContextMenuOpen = false;
    });
}

// 根据选中数量更新菜单项状态
function updateMenuItemsForSelection(menu, count) {
    // 重命名按钮：只能单选时可用
    const renameItem = menu.querySelector('[data-action="rename"]');
    if (renameItem) {
        if (count > 1) {
            renameItem.style.color = '#888';
            renameItem.style.pointerEvents = 'none';
            renameItem.title = '重命名只能对单个文件使用';
        } else {
            renameItem.style.color = '#353a4a';
            renameItem.style.pointerEvents = 'auto';
            renameItem.title = '';
        }
    }
}

function handleAction(action, ids) {
    switch(action) {
        case 'open':
            ids.forEach(id => {
                const item = state.items.find(i => i.id === id);
                if (!item) return;
                if (item.type === 'dir') {
                    const newPath = state.currentPath === '/' ? `/${item.name}` : `${state.currentPath}/${item.name}`;
                    send({cmd: 'ls', path: newPath});
                } else {
                    openFile(id);
                }
            });
            break;
        case 'rename':
            if (ids.length === 1) {
                const item = state.items.find(i => i.id === ids[0]);
                Dialog.prompt('请输入新名称:', item?.name || '', '重命名').then(name => {
                    if (name) {
                        OperationManager.start();
                        send({cmd: 'mv', id: ids[0], name: name});
                    }
                }).catch(() => {});
            } else if (ids.length > 1) {
                Dialog.alert('重命名只能对单个文件或文件夹使用', '提示');
            }
            break;
        case 'copy':
            state.clipboard = {action: 'copy', items: ids};
            break;
        case 'cut':
            state.clipboard = {action: 'cut', items: ids};
            break;
        case 'paste':
            if (state.clipboard.action) {
                OperationManager.start();
                fetch('/paste', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        action: state.clipboard.action,
                        items: state.clipboard.items,
                        target: state.currentPath
                    })
                }).then(() => {
                    state.clipboard = {action: null, items: []};
                    OperationManager.requestSync(500);
                }).catch(() => {
                    OperationManager.end();
                });
            }
            break;
        case 'delete':
            Dialog.confirm(`确定要删除 ${ids.length} 项吗?`, '删除确认').then(confirmed => {
                if (confirmed) {
                    OperationManager.start();
                    send({cmd: 'rm', ids: ids});
                }
            }).catch(() => {});
            break;
        case 'download':
            ids.forEach(id => {
                const a = document.createElement('a');
                a.href = `/file/${id}`;
                a.download = '';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            });
            break;
        case 'mkdir':
            Dialog.prompt('请输入文件夹名称:', '新建文件夹', '新建文件夹').then(name => {
                if (name) {
                    OperationManager.start();
                    send({cmd: 'mkdir', path: state.currentPath, name: name});
                }
            }).catch(() => {});
            break;
        case 'upload':
            document.getElementById('upload_input').click();
            break;
        case 'refresh':
            sfx.back.play();
            send({cmd: 'ls', path: state.currentPath});
            break;
        case 'sort_name':
            state.sortMode = 'name';
            applySort();
            render();
            break;
        case 'sort_size':
            state.sortMode = 'size';
            applySort();
            render();
            break;
        case 'sort_time':
            state.sortMode = 'time';
            applySort();
            render();
            break;
    }
}

function openFile(id) {
    const item = state.items.find(i => i.id === id);
    if (!item) return;
    const ext = item.name.split('.').pop().toLowerCase();
    const images = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
    if (images.includes(ext)) {
        showPreview('image', `/file/${id}`, item.name);
        return;
    }
    const videos = ['mp4', 'avi', 'mkv', 'mov', 'webm'];
    if (videos.includes(ext)) {
        showPreview('video', `/file/${id}`, item.name);
        return;
    }
    const audios = ['mp3', 'wav', 'flac', 'aac', 'ogg'];
    if (audios.includes(ext)) {
        showPreview('audio', `/file/${id}`, item.name);
        return;
    }
    if (ext === 'pdf') {
        window.open(`/file/${id}`, '_blank');
        return;
    }
    const texts = ['txt', 'py', 'js', 'css', 'html', 'json', 'xml', 'ini', 'c', 'cpp', 'h', 'java', 'log', 'md', 'toml'];
    if (texts.includes(ext)) {
        fetch(`/file/${id}`)
            .then(r => {
                if (!r.ok) {
                    throw new Error('Failed to load file');
                }
                return r.text();
            })
            .then(text => showTextViewer(text, item.name))
            .catch(err => {
                console.error('Error loading file:', err);
                Dialog.alert('加载文件失败: ' + err.message);
            });
        return;
    }
    const a = document.createElement('a');
    a.href = `/file/${id}`;
    a.download = item.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function showPreview(type, content, title) {
    const modal = document.getElementById('preview_modal');
    const contentDiv = document.getElementById('preview_content');
    const titleSpan = document.getElementById('preview_title');
    titleSpan.textContent = title;
    switch(type) {
        case 'image':
            contentDiv.innerHTML = `<img src="${content}">`;
            break;
        case 'video':
            contentDiv.innerHTML = `
                <div class="video-container">
                    <div class="video-loading">正在加载...</div>
                    <div class="video-progress">
                        <div class="video-progress-bar"></div>
                    </div>
                    <video 
                        src="${content}" 
                        controls 
                        preload="metadata"
                        playsinline
                    ></video>
                </div>
            `;
            setTimeout(() => {
                const container = contentDiv.querySelector('.video-container');
                const video = container.querySelector('video');
                const loading = container.querySelector('.video-loading');
                const progressBar = container.querySelector('.video-progress-bar');
                
                if (video && loading) {
                    video.addEventListener('loadedmetadata', () => {
                        loading.style.display = 'none';
                    });
                    
                    video.addEventListener('canplay', () => {
                        loading.style.display = 'none';
                        video.play().catch(() => {
                            loading.textContent = '▶ 点击播放';
                            loading.style.display = 'block';
                        });
                    });
                    
                    video.addEventListener('waiting', () => {
                        loading.textContent = '缓冲中...';
                        loading.style.display = 'block';
                    });
                    
                    video.addEventListener('playing', () => {
                        loading.style.display = 'none';
                    });
                    
                    video.addEventListener('progress', () => {
                        if (video.buffered.length > 0 && video.duration) {
                            const bufferedEnd = video.buffered.end(video.buffered.length - 1);
                            const progress = (bufferedEnd / video.duration) * 100;
                            if (progressBar) {
                                progressBar.style.width = progress + '%';
                                if (progress > 10) {
                                    progressBar.parentElement.style.opacity = '0';
                                }
                            }
                        }
                    });
                    
                    video.addEventListener('error', () => {
                        loading.textContent = '加载失败';
                    });
                    
                    loading.addEventListener('click', () => {
                        video.play().catch(() => {});
                    });
                }
            }, 50);
            break;
        case 'audio':
            contentDiv.innerHTML = `<audio src="${content}" controls></audio>`;
            break;
    }
    modal.style.display = 'block';
}

function showTextViewer(content, title) {
    const modal = document.getElementById('preview_modal');
    const contentDiv = document.getElementById('preview_content');
    const titleSpan = document.getElementById('preview_title');
    titleSpan.textContent = title;
    contentDiv.innerHTML = '';
    const pre = document.createElement('pre');
    pre.className = 'text-viewer';
    pre.textContent = content;
    contentDiv.appendChild(pre);
    modal.style.display = 'block';
}

function closePreview() {
    const modal = document.getElementById('preview_modal');
    const contentDiv = document.getElementById('preview_content');
    
    const video = contentDiv.querySelector('video');
    if (video) {
        video.pause();
        video.src = '';
        video.load();
    }
    
    modal.style.display = 'none';
    contentDiv.innerHTML = '';
}

function bindUpload() {
    const input = document.getElementById('upload_input');
    const body = document.getElementById('body');
    const cancelBtn = document.getElementById('upload_cancel');
    const uploadPanel = document.getElementById('upload_panel');
    
    UploadManager.init();
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            cancelAllUploads();
        });
    }
    
    if (uploadPanel) {
        uploadPanel.addEventListener('click', (e) => {
            if (e.target.id !== 'upload_cancel') {
                UploadManager.openList();
            }
        });
    }
    
    input.addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        if (!files.length) return;
        uploadFiles(files);
        input.value = '';
    });
    
    body.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        body.style.backgroundColor = '#a4a1ff';
    });
    
    body.addEventListener('dragleave', (e) => {
        e.preventDefault();
        e.stopPropagation();
        body.style.backgroundColor = '#bfc8ff';
    });
    
    body.addEventListener('drop', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        body.style.backgroundColor = '#bfc8ff';
        const files = Array.from(e.dataTransfer.files);
        if (!files.length) return;
        uploadFiles(files);
    });
}

const UploadManager = {
    queue: [],
    currentIndex: 0,
    currentXhr: null,
    isCancelled: false,
    startTime: 0,
    loadedBytes: 0,
    totalBytes: 0,
    listModal: null,
    listBody: null,
    lastSoundTime: 0,
    soundCooldown: 500,
    uploadedSound: new Audio('sounds/uploaded.mp3'),
    autoCloseTimer: null,

    init() {
        this.listModal = document.getElementById('upload_list_modal');
        this.listBody = document.getElementById('upload_list_body');
        
        if (this.listModal) {
            this.listModal.addEventListener('click', (e) => {
                if (e.target === this.listModal) {
                    this.closeList();
                }
            });
        }
    },

    playUploadedSound() {
        const now = Date.now();
        if (now - this.lastSoundTime >= this.soundCooldown) {
            this.uploadedSound.currentTime = 0;
            this.uploadedSound.play().catch(() => {});
            this.lastSoundTime = now;
        }
    },

    reset() {
        if (this.autoCloseTimer) {
            clearTimeout(this.autoCloseTimer);
            this.autoCloseTimer = null;
        }
        const panel = document.getElementById('upload_panel');
        if (panel) {
            panel.classList.remove('hiding', 'cancelled');
        }
        this.queue = [];
        this.currentIndex = 0;
        this.currentXhr = null;
        this.isCancelled = false;
        this.startTime = 0;
        this.loadedBytes = 0;
        this.totalBytes = 0;
    },

    formatSize(bytes) {
        if (bytes >= 1024 * 1024 * 1024) {
            return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
        } else if (bytes >= 1024 * 1024) {
            return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
        } else if (bytes >= 1024) {
            return (bytes / 1024).toFixed(2) + ' KB';
        } else {
            return bytes + ' B';
        }
    },

    formatSpeed(bytesPerSecond) {
        if (bytesPerSecond >= 1024 * 1024) {
            return (bytesPerSecond / (1024 * 1024)).toFixed(2) + ' MB/s';
        } else if (bytesPerSecond >= 1024) {
            return (bytesPerSecond / 1024).toFixed(2) + ' KB/s';
        } else {
            return bytesPerSecond.toFixed(0) + ' B/s';
        }
    },

    updatePanel() {
        const panel = document.getElementById('upload_panel');
        const currentFile = document.getElementById('upload_current_file');
        const count = document.getElementById('upload_queue_count');
        const speed = document.getElementById('upload_speed_text');
        const percentText = document.getElementById('upload_percent_text');
        const progressBar = document.getElementById('upload_progress');
        
        if (!panel) return;
        
        if (this.queue.length === 0) {
            panel.style.display = 'none';
            return;
        }
        
        panel.style.display = 'block';
        const totalCount = this.queue.length;
        
        const allDone = this.queue.every(item => item.loaded >= item.total || item.error || item.cancelled);
        
        if (allDone) {
            currentFile.textContent = '全部完成';
            count.textContent = `${totalCount}/${totalCount}`;
        } else {
            const pendingIndex = this.queue.findIndex(item => item.loaded < item.total && !item.error && !item.cancelled);
            const currentIdx = pendingIndex >= 0 ? pendingIndex : this.currentIndex;
            const current = this.queue[currentIdx];
            const currentNum = currentIdx + 1;
            
            currentFile.textContent = current ? current.file.name : '准备上传...';
            count.textContent = `${currentNum}/${totalCount}`;
        }
        
        const totalProgress = this.totalBytes > 0 
            ? Math.round((this.loadedBytes / this.totalBytes) * 100)
            : 0;
        progressBar.style.width = totalProgress + '%';
        percentText.textContent = totalProgress + '%';
        
        const elapsed = (Date.now() - this.startTime) / 1000;
        const speedValue = elapsed > 0 ? this.loadedBytes / elapsed : 0;
        speed.textContent = this.formatSpeed(speedValue);
        
        this.updateList();
    },

    updateList() {
        if (!this.listBody) return;
        
        const allDone = this.queue.length > 0 && this.queue.every(item => 
            item.loaded >= item.total || item.error || item.cancelled
        );
        
        if (allDone && !this.autoCloseTimer) {
            this.autoCloseTimer = setTimeout(() => {
                const panel = document.getElementById('upload_panel');
                if (panel) {
                    panel.classList.add('hiding');
                }
                setTimeout(() => {
                    this.closeList();
                    this.reset();
                    if (panel) {
                        panel.classList.remove('hiding');
                        panel.style.display = 'none';
                    }
                }, 400);
            }, 2000);
        }
        
        const existingItems = Array.from(this.listBody.querySelectorAll('.upload_list_item'));
        
        this.queue.forEach((item, index) => {
            let statusClass = 'pending';
            let statusText = '等待中';
            let progressStyle = '';
            
            if (item.cancelled) {
                statusClass = 'cancelled';
                statusText = '已取消';
            } else if (item.error) {
                statusClass = 'error';
                statusText = '失败';
            } else if (item.loaded >= item.total) {
                statusClass = 'done';
                statusText = '完成';
            } else if (index === this.currentIndex && this.currentXhr) {
                statusClass = 'uploading';
                const percent = item.total > 0 ? Math.round((item.loaded / item.total) * 100) : 0;
                statusText = `${percent}%`;
                progressStyle = `${percent}%`;
            }
            
            const existingItem = existingItems[index];
            
            if (existingItem) {
                existingItem.className = `upload_list_item ${statusClass}`;
                if (progressStyle) {
                    existingItem.style.setProperty('--progress', progressStyle);
                }
                const statusEl = existingItem.querySelector('.file_status');
                if (statusEl && statusEl.textContent !== statusText) {
                    statusEl.textContent = statusText;
                }
                
                const canCancel = index >= this.currentIndex && !item.error && !item.cancelled && item.loaded < item.total;
                const cancelBtn = existingItem.querySelector('.item_cancel');
                const placeholder = existingItem.querySelector('.cancel-placeholder');
                
                if (canCancel && !cancelBtn) {
                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'item_cancel';
                    btn.dataset.index = index;
                    btn.title = '取消上传';
                    btn.textContent = '×';
                    if (placeholder) {
                        placeholder.replaceWith(btn);
                    } else {
                        existingItem.insertBefore(btn, existingItem.firstChild);
                    }
                } else if (!canCancel && cancelBtn) {
                    const span = document.createElement('span');
                    span.className = 'cancel-placeholder';
                    span.style.cssText = 'width: 22px; margin-right: 10px; flex-shrink: 0;';
                    cancelBtn.replaceWith(span);
                }
            } else {
                let cancelBtn = '';
                const canCancel = index >= this.currentIndex && !item.error && !item.cancelled && item.loaded < item.total;
                
                if (canCancel) {
                    cancelBtn = `<button type="button" class="item_cancel" data-index="${index}" title="取消上传">×</button>`;
                } else {
                    cancelBtn = `<span class="cancel-placeholder" style="width: 22px; margin-right: 10px; flex-shrink: 0;"></span>`;
                }
                
                let displayName = item.file.name;
                if (displayName.length > 25) {
                    displayName = displayName.substring(0, 12) + '...' + displayName.substring(displayName.length - 10);
                }
                
                const div = document.createElement('div');
                div.className = `upload_list_item ${statusClass} new`;
                div.dataset.index = index;
                if (progressStyle) {
                    div.style.setProperty('--progress', progressStyle);
                }
                div.innerHTML = `
                    ${cancelBtn}
                    <span class="file_name" title="${item.file.name}">${displayName}</span>
                    <span class="file_size">${this.formatSize(item.file.size)}</span>
                    <span class="file_status">${statusText}</span>
                `;
                this.listBody.appendChild(div);
                
                setTimeout(() => {
                    div.classList.remove('new');
                }, 300);
            }
        });
        
        while (existingItems.length > this.queue.length) {
            existingItems.pop().remove();
        }
        
        this.listBody.onmousedown = (e) => {
            const btn = e.target.closest('.item_cancel');
            if (btn) {
                e.stopPropagation();
                e.preventDefault();
                const index = parseInt(btn.dataset.index);
                this.cancelItem(index);
                return false;
            }
        };
    },

    cancelItem(index) {
        const item = this.queue[index];
        if (!item || item.cancelled || item.loaded >= item.total) return;
        
        item.cancelled = true;
        item.loaded = 0;
        
        if (index === this.currentIndex && this.currentXhr) {
            this.currentXhr.abort();
        } else if (index > this.currentIndex) {
            this.totalBytes -= item.total;
        }
        
        this.updatePanel();
        this.updateList();
    },

    openList() {
        if (this.listModal) {
            this.listModal.classList.add('active');
            this.updateList();
        }
    },

    closeList() {
        if (this.listModal) {
            this.listModal.classList.remove('active');
        }
        if (this.autoCloseTimer) {
            clearTimeout(this.autoCloseTimer);
            this.autoCloseTimer = null;
        }
    },

    cancelAll() {
        this.isCancelled = true;
        if (this.currentXhr) {
            this.currentXhr.abort();
        }
        if (this.autoCloseTimer) {
            clearTimeout(this.autoCloseTimer);
            this.autoCloseTimer = null;
        }
        for (let i = this.currentIndex; i < this.queue.length; i++) {
            this.queue[i].cancelled = true;
        }
        
        this.updateList();
        
        const panel = document.getElementById('upload_panel');
        if (panel) {
            panel.classList.add('cancelled');
        }
        
        setTimeout(() => {
            this.closeList();
            this.reset();
            if (panel) {
                panel.classList.remove('cancelled');
                panel.style.display = 'none';
            }
            OperationManager.requestSync(500);
        }, 800);
    },

    async addFiles(files) {
        if (!files || files.length === 0) return;
        
        const isFirstBatch = this.queue.length === 0;
        
        files.forEach(file => {
            this.queue.push({
                file: file,
                loaded: 0,
                total: file.size,
                error: false,
                cancelled: false
            });
            this.totalBytes += file.size;
        });
        
        this.updatePanel();
        
        if (isFirstBatch) {
            this.startTime = Date.now();
            await this.processQueue();
        }
    },

    async processQueue() {
        while (this.currentIndex < this.queue.length && !this.isCancelled) {
            const item = this.queue[this.currentIndex];
            
            if (item.cancelled) {
                this.currentIndex++;
                continue;
            }
            
            this.updatePanel();
            
            try {
                await this.uploadSingle(item);
                if (!item.error && !item.cancelled) {
                    item.loaded = item.total;
                }
                this.currentIndex++;
            } catch (err) {
                if (!this.isCancelled && !item.cancelled) {
                    item.error = true;
                    console.error('Upload error:', err);
                }
                if (item.cancelled) {
                    this.currentIndex++;
                    continue;
                }
                break;
            }
        }
        
        this.updatePanel();
        
        if (!this.isCancelled && this.currentIndex >= this.queue.length) {
            OperationManager.requestSync(500);
            setTimeout(() => {
                this.reset();
                this.updatePanel();
            }, 2000);
        }
    },

    uploadSingle(item) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            this.currentXhr = xhr;
            
            const formData = new FormData();
            formData.append('file', item.file);
            
            const bytesBeforeThisFile = this.loadedBytes;
            
            xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable && !this.isCancelled) {
                    item.loaded = e.loaded;
                    this.loadedBytes = bytesBeforeThisFile + e.loaded;
                    this.updatePanel();
                }
            });
            
            xhr.addEventListener('load', () => {
                this.currentXhr = null;
                if (xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.ok) {
                            this.playUploadedSound();
                            resolve();
                        } else {
                            item.error = true;
                            reject(new Error(response.error || 'Upload failed'));
                        }
                    } catch {
                        item.error = true;
                        reject(new Error('Invalid response'));
                    }
                } else {
                    item.error = true;
                    reject(new Error('HTTP ' + xhr.status));
                }
            });
            
            xhr.addEventListener('error', () => {
                this.currentXhr = null;
                item.error = true;
                reject(new Error('Network error'));
            });
            
            xhr.addEventListener('abort', () => {
                this.currentXhr = null;
                item.cancelled = true;
                reject(new Error('Cancelled'));
            });
            
            xhr.open('POST', `/upload?path=${encodeURIComponent(state.currentPath)}`);
            xhr.send(formData);
        });
    }
};

function uploadFiles(files) {
    return UploadManager.addFiles(files);
}

function cancelAllUploads() {
    return UploadManager.cancelAll();
}

function closeUploadList() {
    return UploadManager.closeList();
}

function bindShortcuts() {
    document.addEventListener('keydown', e => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        
        // 如果右键菜单打开，优先处理菜单相关快捷键
        if (isContextMenuOpen) {
            if (e.key === 'Escape') {
                document.getElementById('file_menu').style.display = 'none';
                document.getElementById('blank_menu').style.display = 'none';
                isContextMenuOpen = false;
                return;
            }
        }
        
        switch(e.key) {
            case 'F5':
            case 'r':
                if (e.ctrlKey) {
                    e.preventDefault();
                    sfx.back.play();
                    send({cmd: 'ls', path: state.currentPath});
                }
                break;
            case 'a':
                if (e.ctrlKey) {
                    e.preventDefault();
                    state.items.forEach(i => state.selected.add(i.id));
                    render();
                }
                break;
            case 'Delete':
                if (state.selected.size > 0) {
                    Dialog.confirm(`确定要删除 ${state.selected.size} 项吗?`, '删除确认').then(confirmed => {
                        if (confirmed) {
                            OperationManager.start();
                            send({cmd: 'rm', ids: Array.from(state.selected)});
                        }
                    }).catch(() => {});
                }
                break;
            case 'c':
                if (e.ctrlKey) {
                    e.preventDefault();
                    state.clipboard = {action: 'copy', items: Array.from(state.selected)};
                }
                break;
            case 'x':
                if (e.ctrlKey) {
                    e.preventDefault();
                    state.clipboard = {action: 'cut', items: Array.from(state.selected)};
                }
                break;
            case 'v':
                if (e.ctrlKey) {
                    e.preventDefault();
                    if (state.clipboard.action) {
                        OperationManager.start();
                        fetch('/paste', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({
                                action: state.clipboard.action,
                                items: state.clipboard.items,
                                target: state.currentPath
                            })
                        }).then(() => {
                            state.clipboard = {action: null, items: []};
                            OperationManager.requestSync(500);
                        }).catch(() => {
                            OperationManager.end();
                        });
                    }
                }
                break;
            case 'n':
                if (e.ctrlKey) {
                    e.preventDefault();
                    Dialog.prompt('请输入文件夹名称:', '新建文件夹', '新建文件夹').then(name => {
                        if (name) {
                            OperationManager.start();
                            send({cmd: 'mkdir', path: state.currentPath, name: name});
                        }
                    }).catch(() => {});
                }
                break;
            case 'F2':
                if (state.selected.size === 1) {
                    const id = Array.from(state.selected)[0];
                    const item = state.items.find(i => i.id === id);
                    Dialog.prompt('请输入新名称:', item?.name || '', '重命名').then(name => {
                        if (name) {
                            OperationManager.start();
                            send({cmd: 'mv', id: id, name: name});
                        }
                    }).catch(() => {});
                } else if (state.selected.size > 1) {
                    Dialog.alert('重命名只能对单个文件或文件夹使用', '提示');
                }
                break;
            case 'Enter':
                if (state.selected.size > 0) {
                    Array.from(state.selected).forEach(id => {
                        const item = state.items.find(i => i.id === id);
                        if (!item) return;
                        if (item.type === 'dir') {
                            const newPath = state.currentPath === '/' ? `/${item.name}` : `${state.currentPath}/${item.name}`;
                            send({cmd: 'ls', path: newPath});
                        } else {
                            openFile(id);
                        }
                    });
                }
                break;
        }
    });
}

function esc(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

document.addEventListener('DOMContentLoaded', () => {
    Dialog.init();
    connect();
    bindEvents();
    bindMenu();
    bindUpload();
    bindShortcuts();
    document.getElementById('preview_modal')?.addEventListener('click', e => {
        if (e.target.id === 'preview_modal') closePreview();
    });
});